/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "OLED.h"
#include "math.h"


#define RXBUFFERSIZE  256     //�������ֽ���

extern const char OLED_Chinese_character16x16[][32];


char RxBuffer2[RXBUFFERSIZE];  //��������
uint8_t aRxBuffer2;			      //�����жϻ���
uint8_t Uart2_Rx_Cnt = 0;     //���ջ������

char RxBuffer3[RXBUFFERSIZE];  //��������
uint8_t aRxBuffer3;			      //�����жϻ���
uint8_t Uart3_Rx_Cnt = 0;     //���ջ������

char Temp[RXBUFFERSIZE]={0};
int i;
double OLEDData[10]={0.0}; 

double StepTemp[10]={0};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */



/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{ 
	/* Prevent unused argument(s) compilation warning */
  UNUSED(huart);
  /* NOTE: This function Should not be modified, when the callback is needed,
           the HAL_UART_TxCpltCallback could be implemented in the user file
   */
	if(huart->Instance == USART2){
		if(Uart2_Rx_Cnt >= 255)  //����ж�
		{
			Uart2_Rx_Cnt = 0;
			memset(RxBuffer2,0x00,sizeof(RxBuffer2));
			HAL_UART_Transmit(&huart2, (uint8_t *)"�������", 10,0xFFFF); 	
		}
		else
		{
			RxBuffer2[Uart2_Rx_Cnt++] = aRxBuffer2;   //

			if((RxBuffer2[Uart2_Rx_Cnt-1] == 0x0A)&&(RxBuffer2[Uart2_Rx_Cnt-2] == 0x0D)) //�жϽ���λ
			{
				
//				
//				HAL_UART_Transmit(&huart2, (uint8_t *)&RxBuffer2, Uart2_Rx_Cnt,0xFFFF); //���յ�����Ϣ���ͳ�ȥ
//      	    while(HAL_UART_GetState(&huart2) == HAL_UART_STATE_BUSY_TX);//���UART���ͽ���
				if(RxBuffer2[0]>='A'&&RxBuffer2[0]<='E'){
					
					for(i=1+RxBuffer2[1]=='-';i<strlen(RxBuffer2);i++){
					Temp[i-1]=RxBuffer2[i];
					}
					if(atof(Temp)!=0)OLEDData[RxBuffer2[0]-'A']=atof(Temp);
				
				}
				Uart2_Rx_Cnt = 0;
				memset(RxBuffer2,0x00,sizeof(RxBuffer2)); //�������
			}
		}
	
		HAL_UART_Receive_IT(&huart2, (uint8_t *)&aRxBuffer2, 1);   //��Ϊ�����ж�ʹ����һ�μ��رգ����������������д��뼴��ʵ������ʹ��
	}
	
		if(huart->Instance == USART3){
		if(Uart3_Rx_Cnt >= 255)  //����ж�
		{
			Uart3_Rx_Cnt = 0;
			memset(RxBuffer3,0x00,sizeof(RxBuffer3));
			HAL_UART_Transmit(&huart3, (uint8_t *)"�������", 10,0xFFFF); 	
		}
		else
		{
			RxBuffer3[Uart3_Rx_Cnt++] = aRxBuffer3;   //

			if((RxBuffer3[Uart3_Rx_Cnt-1] == 0x0A)&&(RxBuffer3[Uart3_Rx_Cnt-2] == 0x0D)) //�жϽ���λ
			{
				
				if(RxBuffer3[0]>='A'&&RxBuffer3[0]<='E'){
					
					for(i=1;i<strlen(RxBuffer3);i++){
					Temp[i-1]=RxBuffer3[i];
					}
					if(atof(Temp))OLEDData[RxBuffer3[0]-'A']=atof(Temp);
				
				}

//				HAL_UART_Transmit(&huart2, (uint8_t *)&RxBuffer3, Uart3_Rx_Cnt,0xFFFF); //���յ�����Ϣ���ͳ�ȥ
//      	    while(HAL_UART_GetState(&huart2) == HAL_UART_STATE_BUSY_TX);//���UART���ͽ���
				Uart3_Rx_Cnt = 0;
				memset(RxBuffer3,0x00,sizeof(RxBuffer3)); //�������
			}
		}
	
		HAL_UART_Receive_IT(&huart3, (uint8_t *)&aRxBuffer3, 1);   //��Ϊ�����ж�ʹ����һ�μ��رգ����������������д��뼴��ʵ������ʹ��
	}
}

char *itoa(int value,char *string,int radix)
{
	char zm[37]="0123456789abcdefghijklmnopqrstuvwxyz";
	char aa[100]={0};
 
	int sum=value;
	char *cp=string;
	int i=0;
	
	if(radix<2||radix>36)//�����˶Դ���ļ��
	{

		return 0;
	}
 
	if(value<0)
	{
		sum*=-1;
	}
	
 
	while(sum>0)
	{
		aa[i++]=zm[sum%radix];
		sum/=radix;
	}
 if(value<0)
	{
		aa[i++]='-';
	}
	for(int j=i-1;j>=0;j--)
	{
		*cp++=aa[j];
	}
	
	
	*cp='\0';
	return string;
}

#define WIFI_SSID        "OPPO Reno8 5G"
#define WIFI_PASSWD      "00000000"

#define MQTT_CLIENT_ID   "123|securemode=2\\,signmethod=hmacsha1\\,timestamp=1689160421294|"   
#define MQTT_USER_NAME   "UsartTest&ikl3w4zpqCv"
#define MQTT_PASSWD      "CCC49B48E4CFB54D588646296A211D5653001279"
#define BROKER_ASDDRESS  "iot-06z00hg45ni60mo.mqtt.iothub.aliyuncs.com"

#define MQTT_DELAY			HAL_Delay(300)
void esp8266_01s_Init(){
	
	MQTT_DELAY;
	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+RST\r\n"), strlen("AT+RST\r\n"),0xFFFF); //����
	MQTT_DELAY;
	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+RESTORE\r\n"), strlen("AT+RESTORE\r\n"),0xFFFF); //���
	MQTT_DELAY;
	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+CWMODE=1\r\n"), strlen("AT+CWMODE=1\r\n"),0xFFFF); //��������ģʽ1
	MQTT_DELAY;
	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+CIPSNTPCFG=1,8,\"ntp1.aliyun.com\"\r\n"), strlen("AT+CIPSNTPCFG=1,8,\"ntp1.aliyun.com\"\r\n"),0xFFFF); //����API
	
	

	MQTT_DELAY;
	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+CIPSNTPCFG=1,8,\"ntp1.aliyun.com\"\r\n"), strlen("AT+CIPSNTPCFG=1,8,\"ntp1.aliyun.com\"\r\n"),0xFFFF); //����wifi
	MQTT_DELAY;
	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+CWJAP=\""WIFI_SSID"\",\""WIFI_PASSWD"\"\r\n"), strlen("AT+CWJAP=\""WIFI_SSID"\",\""WIFI_PASSWD"\"\r\n"),0xFFFF); //����wifi
HAL_Delay(2000);
	MQTT_DELAY;
	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+MQTTUSERCFG=0,1,\"NULL\",\""MQTT_USER_NAME"\",\""MQTT_PASSWD"\",0,0,\"\"\r\n"), strlen("AT+MQTTUSERCFG=0,1,\"NULL\",\""MQTT_USER_NAME"\",\""MQTT_PASSWD"\",0,0,\"\"\r\n"),0xFFFF); //����API

	MQTT_DELAY;
	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+MQTTCLIENTID=0,\""MQTT_CLIENT_ID"\"\r\n"), strlen("AT+MQTTCLIENTID=0,\""MQTT_CLIENT_ID"\"\r\n"),0xFFFF); //����wifi
HAL_Delay(500);
	MQTT_DELAY;
	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+MQTTCONN=0,\""BROKER_ASDDRESS"\",1883,1\r\n"), strlen("AT+MQTTCONN=0,\""BROKER_ASDDRESS"\",1883,1\r\n"),0xFFFF); //����wifi
	HAL_Delay(12000);	
}


void ESP8266_ALY_UP(char *biao,double value){
	char a[10];
	itoa(value,a,10);
	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+MQTTPUB=0,\"/sys/ikl3w4zpqCv/UsartTest/thing/event/property/post\",\"{\\\"method\\\":\\\"thing.service.property.set\\\"\\,\\\"id\\\":\\\"2012934117\\\"\\,\\\"params\\\":{\\\""), strlen("AT+MQTTPUB=0,\"/sys/ikl3w4zpqCv/UsartTest/thing/event/property/post\",\"{\\\"method\\\":\\\"thing.service.property.set\\\"\\,\\\"id\\\":\\\"2012934117\\\"\\,\\\"params\\\":{\\\""),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(biao), strlen(biao),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)("\\\":"), strlen("\\\":"),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(a), strlen(a),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)("}\\,\\\"version\\\":\\\"1.0.0\\\"}\",1,0\r\n"),strlen("}\\,\\\"version\\\":\\\"1.0.0\\\"}\",1,0\r\n"),0xFFFF);
//	HAL_Delay(3000);
}

void ESP8266_ALY_UPJSON(char *biao1,double value1,char *biao2,double value2,char *biao3,double value3,char *biao4,double value4,char *biao5,double value5){
	char a[10][10];
	itoa(value1,a[0],10);itoa(value2,a[1],10);itoa(value3,a[2],10);itoa(value4,a[3],10);itoa(value5,a[4],10);
	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+MQTTPUB=0,\"/sys/ikl3w4zpqCv/UsartTest/thing/event/property/post\",\"{\\\"method\\\":\\\"thing.service.property.set\\\"\\,\\\"id\\\":\\\"00000001\\\"\\,\\\"params\\\":{\\\""), strlen("AT+MQTTPUB=0,\"/sys/ikl3w4zpqCv/UsartTest/thing/event/property/post\",\"{\\\"method\\\":\\\"thing.service.property.set\\\"\\,\\\"id\\\":\\\"00000001\\\"\\,\\\"params\\\":{\\\""),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(biao1), strlen(biao1),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)("\\\":"), strlen("\\\":"),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(a[0]), strlen(a[0]),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(",\\\""), strlen(",\\\""),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(biao2), strlen(biao2),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)("\\\":"), strlen("\\\":"),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(a[1]), strlen(a[1]),0xFFFF);
		HAL_UART_Transmit(&huart1, (uint8_t *)(",\\\""), strlen(",\\\""),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(biao3), strlen(biao3),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)("\\\":"), strlen("\\\":"),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(a[2]), strlen(a[2]),0xFFFF);
		HAL_UART_Transmit(&huart1, (uint8_t *)(",\\\""), strlen(",\\\""),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(biao4), strlen(biao4),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)("\\\":"), strlen("\\\":"),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(a[3]), strlen(a[3]),0xFFFF);
		HAL_UART_Transmit(&huart1, (uint8_t *)(",\\\""), strlen(",\\\""),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(biao5), strlen(biao5),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)("\\\":"), strlen("\\\":"),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)(a[4]), strlen(a[4]),0xFFFF);
	HAL_UART_Transmit(&huart1, (uint8_t *)("}\\,\\\"version\\\":\\\"1.0.0\\\"}\",1,0\r\n"),strlen("}\\,\\\"version\\\":\\\"1.0.0\\\"}\",1,0\r\n"),0xFFFF);
	HAL_Delay(5000);
}


//void ESP8266_ALY_UPJSON(char *biao1,double value1,char *biao2,double value2,char *biao3,double value3,char *biao4,double value4,char *biao5,double value5){
//	char a[10][10];
//	itoa(value1,a[0],10);itoa(value2,a[1],10);itoa(value3,a[2],10);itoa(value4,a[3],10);itoa(value5,a[4],10);
//	HAL_UART_Transmit(&huart1, (uint8_t *)("AT+MQTTPUB=0,\"/sys/ikl3w4zpqCv/UsartTest/thing/event/property/post\",\"{\"method\":\"thing.event.property.post\",\"id\":\"20134117\",\"params\":{\""), strlen("AT+MQTTPUB=0,\"/sys/ikl3w4zpqCv/UsartTest/thing/event/property/post\",\"{\"method\":\"thing.event.property.post\",\"id\":\"20134117\",\"params\":{\""),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)(biao1), strlen(biao1),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)("\":"), strlen("\":"),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)(a[0]), strlen(a[0]),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)(",\""), strlen(",\""),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)(biao2), strlen(biao2),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)("\":"), strlen("\":"),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)(a[1]), strlen(a[1]),0xFFFF);
//		HAL_UART_Transmit(&huart1, (uint8_t *)(",\""), strlen(",\""),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)(biao3), strlen(biao3),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)("\":"), strlen("\":"),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)(a[2]), strlen(a[2]),0xFFFF);
//		HAL_UART_Transmit(&huart1, (uint8_t *)(",\""), strlen(",\""),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)(biao4), strlen(biao4),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)("\":"), strlen("\":"),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)(a[3]), strlen(a[3]),0xFFFF);
//		HAL_UART_Transmit(&huart1, (uint8_t *)(",\""), strlen(",\""),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)(biao5), strlen(biao5),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)("\":"), strlen("\":"),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)(a[4]), strlen(a[4]),0xFFFF);
//	HAL_UART_Transmit(&huart1, (uint8_t *)("},\"version\":\"1.0.0\"}\",1,0\r\n"),strlen("},\"version\":\"1.0.0\"}\",1,0\r\n"),0xFFFF);
//	HAL_Delay(5000);
//}


int IntData=0,sct=0,scc=0;
/* ��ʱ���жϻص� */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
		if(htim->Instance == TIM1) {
			
				if(IntData){sct++;
					if(sct>=200){scc=1;}
				
				
				}
		}
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART3_UART_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
//  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
	HAL_UART_Receive_IT(&huart2, (uint8_t *)&aRxBuffer2, 1);
	HAL_UART_Receive_IT(&huart3, (uint8_t *)&aRxBuffer3, 1);
//HAL_TIM_Base_Start_IT(&htim1);
	OLED_Init();
	OLED_Clear();
	esp8266_01s_Init();

	IntData=1;
//	IntData=1;HAL_UART_Receive_IT(&huart3, (uint8_t *)&aRxBuffer3, 1);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		
		OLED_ShowString(1,1,"t:");
		OLED_ShowDouble(1,3,OLEDData[0],2,2);
		OLED_ShowChinese_character(1,64,OLED_Chinese_character16x16[9]);
		OLED_ShowString(2,1,"x:");
		OLED_ShowDouble(2,3,OLEDData[1],2,2);
		OLED_ShowChinese_character(3,64,OLED_Chinese_character16x16[10]);
		OLED_ShowString(3,1,"y:");
		OLED_ShowDouble(3,3,OLEDData[2],2,2);
		OLED_ShowChinese_character(5,64,OLED_Chinese_character16x16[10]);
		OLED_ShowString(4,1,"a:");
		OLED_ShowDouble(4,3,OLEDData[3],3,0);
		OLED_ShowString(4,8,"Pa");
		
		OLED_ShowChinese_character(1,80,OLED_Chinese_character16x16[7]);
		OLED_ShowChinese_character(1,96,OLED_Chinese_character16x16[8]);
		OLED_ShowChar(1,16,':');
		OLED_ShowNum(2,11,OLEDData[9],4);
		OLED_ShowChinese_character(3,112,OLED_Chinese_character16x16[7]);

		if(OLEDData[0]==0){HAL_UART_Receive_IT(&huart2, (uint8_t *)&aRxBuffer2, 1);}
		if((OLEDData[1]-StepTemp[0]>=1)||(StepTemp[0]-OLEDData[1]>=1)){
			StepTemp[3]=asin((OLEDData[1]-StepTemp[0])/100*3.14/180);
			StepTemp[0]=OLEDData[1];
			StepTemp[9]++;
		}
		if((OLEDData[2]-StepTemp[1]>=1)||(StepTemp[1]-OLEDData[2]>=1)){
			StepTemp[4]=acos((OLEDData[2]-StepTemp[1])/100*3.14/180);
			StepTemp[1]=OLEDData[2];
			StepTemp[9]++;
		}
		if((OLEDData[3]-StepTemp[2]>=1)||(StepTemp[2]-OLEDData[3]>=1)){
			StepTemp[5]=((OLEDData[3]-StepTemp[2]));
			StepTemp[2]=OLEDData[3];
			StepTemp[9]++;
		}
		if(StepTemp[3]+StepTemp[4]+StepTemp[5]>2)OLEDData[9]++;
		
		
		scc++;
		if(scc>=50){

			sct++;
			if((int)(OLEDData[4]/100)!=(int)(OLEDData[1]/100)){sct=2;}OLEDData[4]=OLEDData[1];
			if((int)(OLEDData[5]/1000)!=(int)(OLEDData[2]/1000)){sct=3;}OLEDData[5]=OLEDData[2];
			if((int)(OLEDData[6]/10)!=(int)(OLEDData[3]/10)){sct=4;}OLEDData[6]=OLEDData[3];
			if(OLEDData[9]>OLEDData[8]){sct=5;}OLEDData[8]=OLEDData[9];
			switch(sct){
				case 1:ESP8266_ALY_UP("Temperature",OLEDData[0]/100);break;
				case 2:ESP8266_ALY_UP("Angle_X",OLEDData[1]/100);break;
				case 3:ESP8266_ALY_UP("Angle_Y",OLEDData[2]/100);break;
				case 4:ESP8266_ALY_UP("Airpressure",OLEDData[3]);break;
				case 5:ESP8266_ALY_UP("StepData",OLEDData[9]);break;
				case 6:ESP8266_ALY_UP("power",99);break;
				case 7:sct=0;break;
			}
				
//			ESP8266_ALY_UPJSON("Temperature",OLEDData[0]/100,"Angle_X",OLEDData[1]/100,"Angle_Y",OLEDData[2]/100,"Airpressure",OLEDData[3],"StepData",OLEDData[9]);
				scc=0;
		}
		StepTemp[3]=StepTemp[4]=StepTemp[5]=StepTemp[9]=0;
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 8;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
