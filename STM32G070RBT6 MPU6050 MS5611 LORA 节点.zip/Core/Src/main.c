/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "OLED.h"
#include "mpu6050.h"
#include "MS5611.h"
#include "delay.h"
#include "kalman.h"
#include "string.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

extern const char OLED_Chinese_character16x16[][32];

char TX_TempData[256];
#define RXBUFFERSIZE  256     //�������ֽ���

char RxBuffer2[RXBUFFERSIZE];  //��������
uint8_t aRxBuffer2;			      //�����жϻ���
uint8_t Uart2_Rx_Cnt = 0;     //���ջ������


char Temp[RXBUFFERSIZE]={0};
int i;
double OLEDData[10]={0.0};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{ 
	/* Prevent unused argument(s) compilation warning */
  UNUSED(huart);
  /* NOTE: This function Should not be modified, when the callback is needed,
           the HAL_UART_TxCpltCallback could be implemented in the user file
   */
	if(huart->Instance == USART2){
		if(Uart2_Rx_Cnt >= 255)  //����ж�
		{
			Uart2_Rx_Cnt = 0;
			memset(RxBuffer2,0x00,sizeof(RxBuffer2));
			HAL_UART_Transmit(&huart2, (uint8_t *)"�������", 10,0xFFFF); 	
		}
		else
		{
			RxBuffer2[Uart2_Rx_Cnt++] = aRxBuffer2;   //

			if((RxBuffer2[Uart2_Rx_Cnt-1] == 0x0A)&&(RxBuffer2[Uart2_Rx_Cnt-2] == 0x0D)) //�жϽ���λ
			{
				
				
//				HAL_UART_Transmit(&huart2, (uint8_t *)&RxBuffer2, Uart2_Rx_Cnt,0xFFFF); //���յ�����Ϣ���ͳ�ȥ
//      	    while(HAL_UART_GetState(&huart2) == HAL_UART_STATE_BUSY_TX);//���UART���ͽ���
//				if(RxBuffer2[0]=='Z')
					{
					Temp[0]=1;
						Temp[1]=RxBuffer2[0];
				}
				Uart2_Rx_Cnt = 0;
				memset(RxBuffer2,0x00,sizeof(RxBuffer2)); //�������
			}
		}
	
		HAL_UART_Receive_IT(&huart2, (uint8_t *)&aRxBuffer2, 1);   //��Ϊ�����ж�ʹ����һ�μ��رգ����������������д��뼴��ʵ������ʹ��
	}
	
}

char *itoa(int value,char *string,int radix)
{
	char zm[37]="0123456789abcdefghijklmnopqrstuvwxyz";
	char aa[100]={0};
 
	int sum=value;
	char *cp=string;
	int i=0;
	
	if(radix<2||radix>36)//�����˶Դ���ļ��
	{

		return 0;
	}
 
	if(value<0)
	{
		sum*=-1;
	}
	
 
	while(sum>0)
	{
		aa[i++]=zm[sum%radix];
		sum/=radix;
	}
 if(value<0)
	{
		aa[i++]='-';
	}
	for(int j=i-1;j>=0;j--)
	{
		*cp++=aa[j];
	}
	
	
	*cp='\0';
	return string;
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	int PressureData=0;
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART3_UART_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
	OLED_Init();
	MS5611_init();
	MPU_Init();
	
	HAL_UART_Receive_IT(&huart2, (uint8_t *)&aRxBuffer2, 1);
	
	HAL_Delay(100);MS561101BA_RESET();HAL_Delay(100);
	OLED_Clear();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		Angle_Calcu();PressureData=MS561101BA_getPressure();
		OLED_ShowChinese_character(1,1,OLED_Chinese_character16x16[0]);
		OLED_ShowChinese_character(1,16,OLED_Chinese_character16x16[1]);
		OLED_ShowChar(1,5,'t');
		OLED_ShowChar(1,6,':');
		OLED_Showdouble(1,7,temperature,2,2);
		OLED_ShowChinese_character(1,104,OLED_Chinese_character16x16[9]);
		
		OLED_ShowChinese_character(7,1,OLED_Chinese_character16x16[2]);
		OLED_ShowChinese_character(7,16,OLED_Chinese_character16x16[3]);
		OLED_ShowChar(4,5,'a');
		OLED_ShowChar(4,6,':');
		OLED_Showdouble(4,7,PressureData,3,0);
		OLED_ShowChar(4,11,'P');OLED_ShowChar(4,12,'a');
		
		OLED_ShowChar(2,1,'X');
		OLED_ShowChinese_character(3,8,OLED_Chinese_character16x16[4]);
		OLED_ShowChinese_character(3,24,OLED_Chinese_character16x16[5]);
		OLED_ShowChar(2,6,'x');
		OLED_ShowChar(2,7,':');
		OLED_Showdouble(2,8,Angle_X_Final*100,2,2);
		OLED_ShowChinese_character(3,104,OLED_Chinese_character16x16[10]);
		
		OLED_ShowChar(3,1,'Y');
		OLED_ShowChinese_character(5,8,OLED_Chinese_character16x16[4]);
		OLED_ShowChinese_character(5,24,OLED_Chinese_character16x16[5]);
		OLED_ShowChar(3,6,'y');
		OLED_ShowChar(3,7,':');
		OLED_Showdouble(3,8,Angle_Y_Final*100,2,2);
		OLED_ShowChinese_character(5,104,OLED_Chinese_character16x16[10]);
		HAL_Delay(100);
		
//		if(Temp[0]==1)
//			
		{
//z
			{
		itoa(temperature,TX_TempData,10);
		HAL_UART_Transmit(&huart2, (uint8_t *)&("A"), 1,0xFFFF);
		HAL_UART_Transmit(&huart2, (uint8_t *)&(TX_TempData),strlen(TX_TempData),0xFFFF);
		HAL_UART_Transmit(&huart2, (uint8_t *)&("\r\n"), 2,0xFFFF);HAL_Delay(100);
		while(HAL_UART_GetState(&huart2) == HAL_UART_STATE_BUSY_TX);
		}		
//		if(Temp[1]=='B')
			{
		itoa(Angle_X_Final*100,TX_TempData,10);
		HAL_UART_Transmit(&huart2, (uint8_t *)&("B"), 1,0xFFFF);
		HAL_UART_Transmit(&huart2, (uint8_t *)&(TX_TempData),strlen(TX_TempData),0xFFFF);
		HAL_UART_Transmit(&huart2, (uint8_t *)&("\r\n"), 2,0xFFFF);HAL_Delay(100);
		while(HAL_UART_GetState(&huart2) == HAL_UART_STATE_BUSY_TX);}
//				if(Temp[1]=='C')
					{
		itoa(Angle_Y_Final*100,TX_TempData,10);
		HAL_UART_Transmit(&huart2, (uint8_t *)&("C"), 1,0xFFFF);
		HAL_UART_Transmit(&huart2, (uint8_t *)&(TX_TempData),strlen(TX_TempData),0xFFFF);
		HAL_UART_Transmit(&huart2, (uint8_t *)&("\r\n"), 2,0xFFFF);HAL_Delay(100);
		while(HAL_UART_GetState(&huart2) == HAL_UART_STATE_BUSY_TX);}
//				if(Temp[1]=='D')
					{
		itoa(PressureData,TX_TempData,10);
		HAL_UART_Transmit(&huart2, (uint8_t *)&("D"), 1,0xFFFF);
		HAL_UART_Transmit(&huart2, (uint8_t *)&(TX_TempData),strlen(TX_TempData),0xFFFF);
		HAL_UART_Transmit(&huart2, (uint8_t *)&("\r\n"),2,0xFFFF);HAL_Delay(100);
		while(HAL_UART_GetState(&huart2) == HAL_UART_STATE_BUSY_TX);
						}
		Temp[0]=0;
		}
		
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV1;
  RCC_OscInitStruct.PLL.PLLN = 8;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
