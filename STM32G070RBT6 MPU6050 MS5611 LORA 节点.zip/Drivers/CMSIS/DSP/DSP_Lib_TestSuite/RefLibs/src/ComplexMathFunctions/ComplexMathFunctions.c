
#include "cmplx_conj.c"
#include "cmplx_dot_prod.c"
#include "cmplx_mag.c"
#include "cmplx_mag_squared.c"
#include "cmplx_mult_cmplx.c"
#include "cmplx_mult_real.c"

